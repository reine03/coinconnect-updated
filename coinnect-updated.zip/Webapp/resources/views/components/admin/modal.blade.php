@props(['name', 'title', 'maxWidth' => 'max-w-lg', 'open' => false])
<div x-data="{ show: @js($open), data: {} }"
     x-on:open-modal.window="if ($event.detail.name === '{{ $name }}') { data = $event.detail.data || {}; show = true }"
     x-on:close-modal.window="show = false"
     x-on:keydown.escape.window="show = false"
     x-show="show" x-cloak
     class="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
  <div class="fixed inset-0 bg-slate-900/60" x-on:click="show = false" x-show="show" x-transition.opacity></div>
  <div x-show="show" x-transition
       class="relative bg-white w-full {{ $maxWidth }} rounded-t-2xl sm:rounded-2xl shadow-2xl max-h-[92vh] overflow-y-auto">
    <div class="sticky top-0 bg-white z-10 flex items-center justify-between px-6 py-4 border-b border-slate-100">
      <h2 class="text-lg font-bold text-slate-900">{{ $title }}</h2>
      <button type="button" x-on:click="show = false" class="text-2xl leading-none text-slate-400 hover:text-slate-700" aria-label="Close">&times;</button>
    </div>
    <div class="p-6">
      {{ $slot }}
    </div>
  </div>
</div>
