<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CreditController extends Controller
{
    public function store(Request $request, Customer $customer): RedirectResponse
    {
        $data = $request->validate([
            'type' => ['required', Rule::in(['purchase', 'deduction'])],
            'hours' => ['required', 'numeric', 'min:0.25', 'max:100'],
            'amount' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'note' => ['nullable', 'string', 'max:150'],
        ], [
            'hours.min' => 'Enter at least 0.25 hours (15 minutes).',
        ]);

        $minutes = (int) round(((float) $data['hours']) * 60);

        $error = DB::transaction(function () use ($customer, $data, $minutes, $request) {
            $locked = Customer::lockForUpdate()->findOrFail($customer->id);

            if ($data['type'] === 'deduction') {
                if ($minutes > $locked->credit_minutes) {
                    return 'You can\'t remove more time than the customer has ('.$locked->credit_label.').';
                }
                $locked->decrement('credit_minutes', $minutes);
            } else {
                $locked->increment('credit_minutes', $minutes);
            }

            $locked->creditTransactions()->create([
                'user_id' => $request->user()->id,
                'type' => $data['type'],
                'minutes' => $data['type'] === 'deduction' ? -$minutes : $minutes,
                'amount' => $data['type'] === 'purchase' ? ($data['amount'] ?? 0) : 0,
                'note' => $data['note'] ?? null,
            ]);

            return null;
        });

        if ($error) {
            return back()->withErrors(['hours' => $error]);
        }

        $customer->refresh();
        $verb = $data['type'] === 'purchase' ? 'added to' : 'removed from';

        return back()->with('success', Customer::formatMinutes($minutes)." was {$verb} {$customer->full_name}'s credits. New balance: {$customer->credit_label}.");
    }
}
