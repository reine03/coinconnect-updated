<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title', 'Dashboard') - Coinnect Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = { theme: { extend: { colors: { cn: { dark: '#0d3b66', main: '#1e3a8a', gold: '#ffd700' } } } } };
  </script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
  <style>
    [x-cloak] { display: none !important; }
    body { font-family: ui-sans-serif, system-ui, sans-serif; }
  </style>
  <script>
    document.addEventListener('alpine:init', () => {
      // Live timer for an active play session.
      Alpine.data('sessionTimer', (startedMs, creditMinutes, serverNowMs) => ({
        offset: serverNowMs - Date.now(),
        now: Date.now(),
        init() { setInterval(() => { this.now = Date.now(); }, 1000); },
        get elapsed() { return Math.max(0, Math.floor((this.now + this.offset - startedMs) / 1000)); },
        get remaining() { return creditMinutes * 60 - this.elapsed; },
        get percentLeft() { return creditMinutes > 0 ? Math.max(0, Math.min(100, (this.remaining / (creditMinutes * 60)) * 100)) : 0; },
        get low() { return this.remaining <= 600; },
        get over() { return this.remaining <= 0; },
        fmt(sec) {
          sec = Math.max(0, sec);
          const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
          return [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
        },
      }));

      // Photo picker: upload a file or capture from the webcam.
      Alpine.data('photoPicker', (currentUrl = null) => ({
        preview: currentUrl,
        camera: false,
        stream: null,
        error: null,
        pick(event) {
          const file = event.target.files[0];
          if (file) { this.preview = URL.createObjectURL(file); }
        },
        async openCamera() {
          this.error = null;
          try {
            this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
            this.camera = true;
            this.$nextTick(() => { this.$refs.video.srcObject = this.stream; });
          } catch (e) {
            this.error = 'Camera not available. Allow camera access, or upload a file instead.';
          }
        },
        closeCamera() {
          if (this.stream) { this.stream.getTracks().forEach(t => t.stop()); }
          this.stream = null;
          this.camera = false;
        },
        snap() {
          const video = this.$refs.video;
          const size = Math.min(video.videoWidth, video.videoHeight);
          const canvas = document.createElement('canvas');
          canvas.width = canvas.height = 600;
          canvas.getContext('2d').drawImage(video, (video.videoWidth - size) / 2, (video.videoHeight - size) / 2, size, size, 0, 0, 600, 600);
          canvas.toBlob((blob) => {
            const file = new File([blob], 'webcam-' + Date.now() + '.jpg', { type: 'image/jpeg' });
            const dt = new DataTransfer();
            dt.items.add(file);
            this.$refs.file.files = dt.files;
            this.preview = URL.createObjectURL(file);
            this.closeCamera();
          }, 'image/jpeg', 0.9);
        },
      }));
    });
  </script>
</head>
<body class="bg-slate-100 text-slate-800 antialiased" x-data="{ sidebar: false }">

  {{-- Mobile overlay --}}
  <div x-cloak x-show="sidebar" x-on:click="sidebar = false" class="fixed inset-0 z-30 bg-black/50 lg:hidden"></div>

  {{-- Sidebar --}}
  <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-cn-dark text-blue-100 flex flex-col transition-transform duration-200 lg:translate-x-0"
         :class="sidebar ? 'translate-x-0' : '-translate-x-full'">
    <div class="flex items-center gap-3 px-6 h-16 border-b border-white/10">
      <div class="w-9 h-9 rounded-full bg-cn-gold flex items-center justify-center shadow">
        <svg viewBox="0 0 100 100" class="w-6 h-6 fill-white"><circle cx="50" cy="50" r="20"/><path d="M40 50 L60 50 M50 40 L50 60" stroke="white" stroke-width="6"/></svg>
      </div>
      <div class="leading-tight">
        <div class="font-extrabold tracking-wide text-white">COINNECT</div>
        <div class="text-[10px] uppercase tracking-widest text-blue-300">Admin Portal</div>
      </div>
    </div>

    @php
      $nav = [
        ['dashboard', 'Dashboard', 'M3 12l9-9 9 9M5 10v10h5v-6h4v6h5V10'],
        ['computers.index', 'Computers', 'M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
        ['customers.index', 'Customers', 'M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-4.13a4 4 0 11-8 0 4 4 0 018 0zm6 0a3 3 0 11-6 0 3 3 0 016 0z'],
        ['sessions.index', 'Time Log', 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'],
      ];
    @endphp
    <nav class="flex-1 px-3 py-5 space-y-1">
      @foreach ($nav as [$route, $label, $icon])
        @php $active = request()->routeIs(explode('.', $route)[0].'*'); @endphp
        <a href="{{ route($route) }}"
           class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition {{ $active ? 'bg-white/15 text-white' : 'hover:bg-white/10 hover:text-white' }}">
          <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="{{ $icon }}"/></svg>
          {{ $label }}
        </a>
      @endforeach
    </nav>

    <div class="p-4 border-t border-white/10">
      <div class="flex items-center gap-3 mb-3">
        <div class="w-9 h-9 rounded-full bg-cn-main flex items-center justify-center text-white font-bold">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</div>
        <div class="min-w-0">
          <div class="text-sm font-semibold text-white truncate">{{ auth()->user()->name }}</div>
          <div class="text-xs text-blue-300 truncate">{{ auth()->user()->username ? '@'.auth()->user()->username : auth()->user()->email }}</div>
        </div>
      </div>
      <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button class="w-full text-left text-sm font-semibold px-3 py-2 rounded-lg hover:bg-white/10 hover:text-white transition">Log out</button>
      </form>
    </div>
  </aside>

  <div class="lg:pl-64 min-h-screen flex flex-col">
    {{-- Top bar --}}
    <header class="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-slate-200 h-16 px-4 sm:px-8 flex items-center gap-4">
      <button class="lg:hidden p-2 -ml-2 rounded-lg hover:bg-slate-100" x-on:click="sidebar = true" aria-label="Open menu">
        <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
      <div>
        <h1 class="text-lg font-bold text-slate-900 leading-tight">@yield('heading', 'Dashboard')</h1>
        @hasSection('subheading')<p class="text-xs text-slate-500">@yield('subheading')</p>@endif
      </div>
      <div class="ml-auto flex items-center gap-3">
        @yield('actions')
      </div>
    </header>

    <main class="flex-1 p-4 sm:p-8 space-y-6">
      @if (session('success'))
        <div x-data="{ open: true }" x-show="open" x-init="setTimeout(() => open = false, 7000)" x-transition
             class="flex items-start gap-3 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
          <svg class="w-5 h-5 mt-0.5 shrink-0 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
          <span class="flex-1">{{ session('success') }}</span>
          <button x-on:click="open = false" class="text-green-700 hover:text-green-900" aria-label="Dismiss">&times;</button>
        </div>
      @endif

      @if ($errors->any())
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <div class="font-semibold mb-1">Please fix the following:</div>
          <ul class="list-disc pl-5 space-y-0.5">
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @endif

      @yield('content')
    </main>
  </div>
</body>
</html>
