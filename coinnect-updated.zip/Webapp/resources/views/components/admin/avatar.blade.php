@props(['customer', 'size' => 'w-10 h-10', 'text' => 'text-sm'])
@if ($customer->photo_url)
  <img src="{{ $customer->photo_url }}" alt="{{ $customer->full_name }}" loading="lazy"
       {{ $attributes->merge(['class' => "$size rounded-full object-cover ring-2 ring-white shadow shrink-0 bg-slate-200"]) }}>
@else
  <div {{ $attributes->merge(['class' => "$size $text rounded-full bg-gradient-to-br from-cn-main to-cn-dark text-white font-bold flex items-center justify-center ring-2 ring-white shadow shrink-0"]) }}>
    {{ $customer->initials }}
  </div>
@endif
