{{-- Add / remove credits. Open with: $dispatch('open-modal', { name: 'credits', data: { id, name, balance } }) --}}
<x-admin.modal name="credits" title="Playtime credits" max-width="max-w-md">
  <form method="POST" x-bind:action="'{{ route('customers.credits.store', ':id') }}'.replace(':id', data.id)"
        x-data="{ type: 'purchase', hours: '', presets: [0.5, 1, 2, 3, 5, 10] }"
        x-effect="if (!show) { type = 'purchase'; hours = '' }">
    @csrf
    <div class="rounded-xl bg-slate-50 px-4 py-3 mb-4">
      <div class="text-sm font-bold text-slate-900" x-text="data.name"></div>
      <div class="text-xs text-slate-500">Current balance: <span class="font-bold text-emerald-600" x-text="data.balance"></span></div>
    </div>

    <div class="grid grid-cols-2 gap-2 mb-4 p-1 bg-slate-100 rounded-lg">
      <label class="text-center py-2 rounded-md text-sm font-semibold cursor-pointer" :class="type === 'purchase' ? 'bg-white shadow text-emerald-700' : 'text-slate-500'">
        <input type="radio" name="type" value="purchase" x-model="type" class="sr-only">Add time
      </label>
      <label class="text-center py-2 rounded-md text-sm font-semibold cursor-pointer" :class="type === 'deduction' ? 'bg-white shadow text-red-600' : 'text-slate-500'">
        <input type="radio" name="type" value="deduction" x-model="type" class="sr-only">Remove time
      </label>
    </div>

    <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Hours</label>
    <div class="flex flex-wrap gap-2 mb-2">
      <template x-for="p in presets" :key="p">
        <button type="button" x-on:click="hours = p" class="px-3 py-1 rounded-full text-xs font-bold border"
                :class="Number(hours) === p ? 'bg-cn-main text-white border-cn-main' : 'bg-white text-slate-600 border-slate-300 hover:border-cn-main'" x-text="p + 'h'"></button>
      </template>
    </div>
    <input type="number" name="hours" x-model="hours" step="0.25" min="0.25" max="100" required placeholder="e.g. 2.5"
           class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">

    <div x-show="type === 'purchase'" class="mt-4">
      <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Amount paid (₱) <span class="font-normal normal-case text-slate-400">(optional)</span></label>
      <input type="number" name="amount" step="0.01" min="0" placeholder="0.00"
             class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
    </div>

    <div class="mt-4">
      <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Note <span class="font-normal normal-case text-slate-400">(optional)</span></label>
      <input type="text" name="note" maxlength="150" placeholder="e.g. Promo, refund, correction"
             class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
    </div>

    <div class="mt-5 flex justify-end gap-2">
      <button type="button" x-on:click="show = false" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Cancel</button>
      <button type="submit" class="px-5 py-2 rounded-lg text-white text-sm font-bold"
              :class="type === 'purchase' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'"
              x-text="type === 'purchase' ? 'Add credits' : 'Remove credits'">Add credits</button>
    </div>
  </form>
</x-admin.modal>
