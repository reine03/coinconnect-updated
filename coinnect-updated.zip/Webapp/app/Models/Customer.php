<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Str;

#[Fillable(['account_no', 'full_name', 'contact_number', 'email', 'photo_path', 'credit_minutes', 'is_active'])]
class Customer extends Model
{
    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'credit_minutes' => 'integer',
        ];
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(PlaySession::class);
    }

    public function activeSession(): HasOne
    {
        return $this->hasOne(PlaySession::class)->whereNull('ended_at');
    }

    public function creditTransactions(): HasMany
    {
        return $this->hasMany(CreditTransaction::class);
    }

    public function getPhotoUrlAttribute(): ?string
    {
        return $this->photo_path ? asset('storage/'.$this->photo_path) : null;
    }

    public function getInitialsAttribute(): string
    {
        return Str::of($this->full_name)->explode(' ')->filter()->take(2)
            ->map(fn ($part) => Str::upper(Str::substr($part, 0, 1)))->implode('');
    }

    public function getCreditLabelAttribute(): string
    {
        return self::formatMinutes($this->credit_minutes);
    }

    /**
     * Format minutes as "2h 30m".
     */
    public static function formatMinutes(int $minutes): string
    {
        $minutes = max(0, $minutes);

        return intdiv($minutes, 60).'h '.str_pad((string) ($minutes % 60), 2, '0', STR_PAD_LEFT).'m';
    }
}
