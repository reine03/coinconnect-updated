<?php

namespace App\Http\Requests\Auth;

use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
            'username' => Str::lower(trim((string) $this->input('username'))),
            'email' => Str::lower(trim((string) $this->input('email'))),
        ]);
    }

    /**
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'min:2', 'max:60', "regex:/^[\pL][\pL\s.'-]*$/u"],
            'username' => [
                'required',
                'string',
                'min:4',
                'max:20',
                'regex:/^[a-z][a-z0-9_]*$/',
                'unique:'.User::class.',username',
            ],
            'email' => ['required', 'string', 'email:rfc', 'max:255', 'unique:'.User::class],
            'password' => [
                'required',
                'confirmed',
                Password::min(8)->max(64)->letters()->mixedCase()->numbers()->symbols(),
                function (string $attribute, mixed $value, \Closure $fail) {
                    $username = (string) $this->input('username');

                    if ($username !== '' && str_contains(Str::lower((string) $value), $username)) {
                        $fail('The password must not contain your username.');
                    }
                },
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'name.regex' => 'Your name may only contain letters, spaces, apostrophes, hyphens and periods.',
            'username.min' => 'Your username must be at least 4 characters.',
            'username.max' => 'Your username must not be longer than 20 characters.',
            'username.regex' => 'Your username must start with a letter and may only contain letters, numbers and underscores.',
            'username.unique' => 'That username is already taken. Please choose another one.',
            'email.unique' => 'An admin account with that email already exists.',
            'password.confirmed' => 'The password confirmation does not match.',
        ];
    }
}
