@extends('layouts.admin')

@section('title', $customer->full_name)
@section('heading', 'Customer Profile')
@section('subheading', $customer->account_no)

@section('actions')
  <a href="{{ route('customers.index') }}" class="text-sm font-semibold text-slate-500 hover:text-slate-800">← All customers</a>
@endsection

@section('content')
  @php $session = $customer->activeSession; @endphp

  <div class="grid lg:grid-cols-3 gap-6">
    {{-- Profile card --}}
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col items-center text-center">
      <x-admin.avatar :customer="$customer" size="w-36 h-36" text="text-5xl" />
      <h2 class="mt-4 text-xl font-extrabold text-slate-900">{{ $customer->full_name }}</h2>
      <div class="text-sm text-slate-400">{{ $customer->account_no }}</div>

      <div class="mt-3">
        @if (! $customer->is_active)
          <span class="px-3 py-1 rounded-full bg-slate-200 text-slate-600 text-xs font-bold">Inactive</span>
        @elseif ($session)
          <span class="px-3 py-1 rounded-full bg-red-100 text-red-700 text-xs font-bold">Playing on {{ $session->computer->name }}</span>
        @else
          <span class="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">Active · Offline</span>
        @endif
      </div>

      <div class="mt-5 w-full rounded-xl bg-slate-50 py-4">
        <div class="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Playtime credits</div>
        <div class="text-3xl font-extrabold {{ $customer->credit_minutes > 0 ? 'text-emerald-600' : 'text-red-500' }}">{{ $customer->credit_label }}</div>
      </div>

      <dl class="mt-5 w-full text-sm space-y-2 text-left">
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Contact</dt><dd class="font-medium text-right">{{ $customer->contact_number ?: '—' }}</dd></div>
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Email</dt><dd class="font-medium text-right break-all">{{ $customer->email ?: '—' }}</dd></div>
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Registered</dt><dd class="font-medium text-right">{{ $customer->created_at->format('M j, Y') }}</dd></div>
      </dl>

      <div class="mt-6 w-full grid grid-cols-2 gap-2" x-data>
        <button type="button"
                x-on:click="$dispatch('open-modal', { name: 'credits', data: { id: {{ $customer->id }}, name: @js($customer->full_name), balance: @js($customer->credit_label) } })"
                class="py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">+ Credits</button>
        <button type="button" x-on:click="$dispatch('open-modal', { name: 'edit-customer' })"
                class="py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Edit</button>
      </div>

      @if ($session)
        <form method="POST" action="{{ route('sessions.end', $session) }}" class="mt-2 w-full" onsubmit="return confirm('Time out this customer?')">
          @csrf @method('PATCH')
          <button class="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-bold">Time Out</button>
        </form>
      @endif
    </div>

    {{-- History --}}
    <div class="lg:col-span-2 space-y-6">
      <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-100"><h3 class="font-bold text-slate-900">Time in / out history</h3></div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
              <tr>
                <th class="px-5 py-3 text-left font-bold">PC</th>
                <th class="px-5 py-3 text-left font-bold">Time In</th>
                <th class="px-5 py-3 text-left font-bold">Time Out</th>
                <th class="px-5 py-3 text-left font-bold">Used</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @forelse ($sessions as $s)
                <tr>
                  <td class="px-5 py-3 font-semibold">{{ $s->computer->name }}</td>
                  <td class="px-5 py-3 text-slate-600 whitespace-nowrap">{{ $s->started_at->format('M j, g:i A') }}</td>
                  <td class="px-5 py-3 whitespace-nowrap">{!! $s->ended_at ? e($s->ended_at->format('M j, g:i A')) : '<span class="text-red-600 font-bold">Playing</span>' !!}</td>
                  <td class="px-5 py-3 font-semibold">{{ $s->ended_at ? \App\Models\Customer::formatMinutes($s->minutes_charged) : '—' }}</td>
                </tr>
              @empty
                <tr><td colspan="4" class="px-5 py-8 text-center text-slate-400">No sessions yet.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </section>

      <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-100"><h3 class="font-bold text-slate-900">Credit history</h3></div>
        <div class="overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
              <tr>
                <th class="px-5 py-3 text-left font-bold">Date</th>
                <th class="px-5 py-3 text-left font-bold">Change</th>
                <th class="px-5 py-3 text-left font-bold">Paid</th>
                <th class="px-5 py-3 text-left font-bold">Note</th>
                <th class="px-5 py-3 text-left font-bold">By</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @forelse ($transactions as $t)
                <tr>
                  <td class="px-5 py-3 text-slate-600 whitespace-nowrap">{{ $t->created_at->format('M j, g:i A') }}</td>
                  <td class="px-5 py-3 font-bold whitespace-nowrap {{ $t->minutes >= 0 ? 'text-emerald-600' : 'text-red-600' }}">{{ $t->minutes >= 0 ? '+' : '−' }}{{ \App\Models\Customer::formatMinutes(abs($t->minutes)) }}</td>
                  <td class="px-5 py-3">{{ $t->amount > 0 ? '₱'.number_format($t->amount, 2) : '—' }}</td>
                  <td class="px-5 py-3 text-slate-500">{{ $t->note ?: '—' }}</td>
                  <td class="px-5 py-3 text-slate-500">{{ $t->admin?->name ?? '—' }}</td>
                </tr>
              @empty
                <tr><td colspan="5" class="px-5 py-8 text-center text-slate-400">No credit activity yet.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  @include('customers._credit-modal')

  {{-- Edit modal --}}
  <x-admin.modal name="edit-customer" title="Edit customer" max-width="max-w-xl">
    <form method="POST" action="{{ route('customers.update', $customer) }}" enctype="multipart/form-data" class="space-y-4">
      @csrf @method('PATCH')
      <x-admin.photo-picker :current="$customer->photo_url" />

      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Full name</label>
        <input type="text" name="full_name" required maxlength="100" value="{{ old('full_name', $customer->full_name) }}"
               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
      </div>
      <div class="grid sm:grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Contact no.</label>
          <input type="text" name="contact_number" maxlength="20" value="{{ old('contact_number', $customer->contact_number) }}"
                 class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
        </div>
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Email</label>
          <input type="email" name="email" maxlength="255" value="{{ old('email', $customer->email) }}"
                 class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
        </div>
      </div>
      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Account status</label>
        <select name="is_active" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main">
          <option value="1" @selected($customer->is_active)>Active</option>
          <option value="0" @selected(! $customer->is_active)>Inactive</option>
        </select>
      </div>

      <div class="flex items-center justify-between gap-2 pt-2">
        <button type="submit" form="delete-customer" class="px-3 py-2 rounded-lg text-sm font-semibold text-red-600 hover:bg-red-50">Delete account</button>
        <div class="flex gap-2">
          <button type="button" x-on:click="show = false" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Cancel</button>
          <button type="submit" class="px-5 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-bold">Save changes</button>
        </div>
      </div>
    </form>
    <form id="delete-customer" method="POST" action="{{ route('customers.destroy', $customer) }}"
          onsubmit="return confirm('Delete this customer and all of their history? This cannot be undone.')">
      @csrf @method('DELETE')
    </form>
  </x-admin.modal>
@endsection
