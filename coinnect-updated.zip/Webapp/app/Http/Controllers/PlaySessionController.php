<?php

namespace App\Http\Controllers;

use App\Models\Computer;
use App\Models\Customer;
use App\Models\PlaySession;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class PlaySessionController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim((string) $request->query('q'));
        $status = $request->query('status');
        $date = $request->query('date');

        $sessions = PlaySession::with(['customer', 'computer'])
            ->when($status === 'active', fn ($q) => $q->whereNull('ended_at'))
            ->when($status === 'finished', fn ($q) => $q->whereNotNull('ended_at'))
            ->when($date, fn ($q) => $q->whereDate('started_at', $date))
            ->when($search !== '', fn ($q) => $q->where(function ($q) use ($search) {
                $q->whereHas('customer', fn ($c) => $c->where('full_name', 'like', "%{$search}%")->orWhere('account_no', 'like', "%{$search}%"))
                    ->orWhereHas('computer', fn ($c) => $c->where('name', 'like', "%{$search}%"));
            }))
            ->latest('started_at')
            ->paginate(15)
            ->withQueryString();

        return view('sessions.index', compact('sessions', 'search', 'status', 'date'));
    }

    /**
     * Time in: start a session for a customer on a computer.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'computer_id' => ['required', 'exists:computers,id'],
            'customer_id' => ['required', 'exists:customers,id'],
        ], [
            'customer_id.required' => 'Please choose a customer to time in.',
        ]);

        $result = DB::transaction(function () use ($data, $request) {
            $computer = Computer::lockForUpdate()->findOrFail($data['computer_id']);
            $customer = Customer::lockForUpdate()->findOrFail($data['customer_id']);

            if ($computer->status !== 'available') {
                return "{$computer->name} is under maintenance.";
            }
            if ($computer->activeSession()->exists()) {
                return "{$computer->name} is already in use.";
            }
            if (! $customer->is_active) {
                return "{$customer->full_name}'s account is inactive.";
            }
            if ($customer->activeSession()->exists()) {
                return "{$customer->full_name} is already playing on another PC.";
            }
            if ($customer->credit_minutes <= 0) {
                return "{$customer->full_name} has no playtime credits left.";
            }

            PlaySession::create([
                'customer_id' => $customer->id,
                'computer_id' => $computer->id,
                'user_id' => $request->user()->id,
                'started_at' => now(),
            ]);

            return ["{$customer->full_name} timed in on {$computer->name}. Balance: {$customer->credit_label}."];
        });

        if (is_string($result)) {
            return back()->withErrors(['timein' => $result]);
        }

        return back()->with('success', $result[0]);
    }

    /**
     * Time out: end a session and deduct the used time.
     */
    public function end(PlaySession $session): RedirectResponse
    {
        if (! $session->isActive()) {
            return back()->withErrors(['timeout' => 'That session has already ended.']);
        }

        $session->load(['customer', 'computer']);
        $charged = $session->timeOut();
        $session->customer->refresh();

        return back()->with('success', "{$session->customer->full_name} timed out of {$session->computer->name}. Used ".Customer::formatMinutes($charged).", remaining {$session->customer->credit_label}.");
    }
}
