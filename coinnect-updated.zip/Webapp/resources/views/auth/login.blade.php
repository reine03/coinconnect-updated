<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login - Coinnect</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
  <style>
    [x-cloak] { display: none !important; }
    .cn-blue-dark { background-color: #0d3b66; }
    .cn-blue-main { background-color: #1e3a8a; }
    .cn-text-blue { color: #1e3a8a; }
    .gold-ring {
      background: conic-gradient(#ffd700 0deg 120deg, #ffcc00 120deg 240deg, #b8860b 240deg 360deg);
    }
    body {
      background: linear-gradient(135deg, #cfd3db 0%, #a9afba 50%, #7c818a 100%);
      min-height: 100vh;
      font-family: sans-serif;
      position: relative;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      background-image: linear-gradient(#00000012 1px, transparent 1px), linear-gradient(90deg, #00000012 1px, transparent 1px);
      background-size: 40px 40px;
      pointer-events: none;
    }
    body::after {
      content: "";
      position: fixed;
      inset: 0;
      background: radial-gradient(circle at center, transparent 65%, rgba(0,0,0,0.25) 100%);
      pointer-events: none;
    }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 font-sans">

  <div class="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 relative z-10">
    <div class="cn-blue-dark p-8 text-center flex flex-col items-center justify-center">
      <div class="relative w-24 h-24 rounded-full p-1 gold-ring shadow-lg mb-3">
        <div class="w-full h-full bg-[#ffd700] rounded-full flex items-center justify-center overflow-hidden">
          <svg viewBox="0 0 100 100" class="w-16 h-16 fill-white">
            <circle cx="50" cy="50" r="20" />
            <path d="M40 50 L60 50 M50 40 L50 60" stroke="white" stroke-width="4"/>
          </svg>
        </div>
      </div>
      <h1 class="text-2xl font-extrabold text-white tracking-wide">COINNECT</h1>
      <p class="text-blue-200 text-sm mt-1 font-medium">Admin Portal &middot; Sign in to manage the hub 🎮</p>
    </div>

    <form action="{{ route('login') }}" method="POST" class="p-8 space-y-4" x-data="{ show: false, busy: false }" x-on:submit="busy = true">
      @csrf

      {{-- Success message (e.g. after registration) --}}
      @if (session('status'))
        <div class="flex items-start gap-3 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800" role="status">
          <svg class="w-5 h-5 mt-0.5 shrink-0 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
          <span>{{ session('status') }}</span>
        </div>
      @endif

      {{-- Login error --}}
      @error('login')
        <div class="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
          <svg class="w-5 h-5 mt-0.5 shrink-0 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"/></svg>
          <span>{{ $message }}</span>
        </div>
      @enderror

      <div>
        <label for="login" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Username or Email</label>
        <input type="text" id="login" name="login" value="{{ old('login', session('registered_username')) }}" required autofocus autocomplete="username" autocapitalize="none"
               class="w-full px-4 py-3 rounded-lg border @error('login') border-red-400 @else border-gray-300 @enderror focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
               placeholder="your_username">
      </div>

      <div>
        <div class="flex justify-between items-center mb-1">
          <label for="password" class="block text-xs font-bold text-gray-700 uppercase tracking-wider">Password</label>
          @if (Route::has('password.request'))
            <a href="{{ route('password.request') }}" class="text-xs cn-text-blue font-semibold hover:underline">Forgot?</a>
          @endif
        </div>
        <div class="relative">
          <input :type="show ? 'text' : 'password'" id="password" name="password" required autocomplete="current-password"
                 class="w-full px-4 py-3 pr-12 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
                 placeholder="••••••••">
          <button type="button" x-on:click="show = !show" class="absolute inset-y-0 right-0 px-4 text-xs font-bold text-gray-500 hover:text-[#1e3a8a]" :aria-label="show ? 'Hide password' : 'Show password'">
            <span x-text="show ? 'HIDE' : 'SHOW'">SHOW</span>
          </button>
        </div>
        @error('password')
          <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
        @enderror
      </div>

      <div class="flex items-center">
        <input type="checkbox" id="remember" name="remember" class="w-4 h-4 text-[#1e3a8a] focus:ring-[#1e3a8a] border-gray-300 rounded">
        <label for="remember" class="ml-2 text-xs text-gray-600 font-medium">Keep me signed in</label>
      </div>

      <button type="submit" x-bind:disabled="busy"
              class="w-full mt-2 cn-blue-main hover:bg-[#0d3b66] disabled:opacity-70 text-white font-bold py-3.5 px-4 rounded-full shadow-md hover:shadow-lg transition duration-200">
        <span x-text="busy ? 'Signing in…' : 'Sign In'">Sign In</span>
      </button>
    </form>

    <div class="px-8 pb-8 text-center bg-gray-50 border-t border-gray-100 pt-4">
      <p class="text-sm text-gray-600">New admin?</p>
      <a href="{{ route('register') }}" class="cn-text-blue font-bold text-sm hover:underline mt-1 inline-block">Create an Admin Account</a>
    </div>
  </div>

</body>
</html>
