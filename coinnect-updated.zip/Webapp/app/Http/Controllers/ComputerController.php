<?php

namespace App\Http\Controllers;

use App\Models\Computer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ComputerController extends Controller
{
    public function index(): View
    {
        $computers = Computer::with('activeSession.customer')->orderBy('name')->get();

        return view('computers.index', compact('computers'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);

        Computer::create($data);

        return back()->with('success', "{$data['name']} was added.");
    }

    public function update(Request $request, Computer $computer): RedirectResponse
    {
        $data = $this->validated($request, $computer);

        if ($data['status'] === 'maintenance' && $computer->activeSession()->exists()) {
            return back()->withErrors(['status' => "{$computer->name} is in use. Time the customer out before setting it to maintenance."]);
        }

        $computer->update($data);

        return back()->with('success', "{$computer->name} was updated.");
    }

    public function destroy(Computer $computer): RedirectResponse
    {
        if ($computer->sessions()->exists()) {
            return back()->withErrors(['delete' => "{$computer->name} has session history and can't be deleted. Set it to maintenance instead."]);
        }

        $computer->delete();

        return back()->with('success', "{$computer->name} was deleted.");
    }

    private function validated(Request $request, ?Computer $computer = null): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:30', Rule::unique('computers', 'name')->ignore($computer)],
            'tier' => ['required', Rule::in(array_keys(Computer::TIERS))],
            'specs' => ['nullable', 'string', 'max:500'],
            'status' => ['required', Rule::in(array_keys(Computer::STATUSES))],
        ]);
    }
}
