@extends('layouts.admin')

@section('title', 'Time Log')
@section('heading', 'Time In / Time Out Log')
@section('subheading', 'Every session, with who played and for how long')

@section('content')
  <form method="GET" class="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 flex flex-wrap items-end gap-3">
    <div class="flex-1 min-w-[200px]">
      <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Search</label>
      <input type="search" name="q" value="{{ $search }}" placeholder="Customer, account no. or PC"
             class="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
    </div>
    <div>
      <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Date</label>
      <input type="date" name="date" value="{{ $date }}" class="px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cn-main">
    </div>
    <div>
      <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Status</label>
      <select name="status" class="px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cn-main">
        <option value="">All</option>
        <option value="active" @selected($status === 'active')>Playing now</option>
        <option value="finished" @selected($status === 'finished')>Finished</option>
      </select>
    </div>
    <button class="px-5 py-2.5 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-semibold">Filter</button>
    @if ($search || $status || $date)
      <a href="{{ route('sessions.index') }}" class="px-3 py-2.5 text-sm font-semibold text-slate-500 hover:text-slate-800">Clear</a>
    @endif
  </form>

  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    @include('sessions._table', ['sessions' => $sessions])
    @if ($sessions->hasPages())
      <div class="px-5 py-4 border-t border-slate-100">{{ $sessions->links() }}</div>
    @endif
  </div>
@endsection
