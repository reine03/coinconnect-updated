@extends('layouts.admin')

@section('title', 'Dashboard')
@section('heading', 'Dashboard')
@section('subheading', now()->format('l, F j, Y'))

@section('actions')
  <a href="{{ route('customers.index') }}" class="hidden sm:inline-flex items-center px-4 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-semibold shadow-sm">+ Register customer</a>
@endsection

@section('content')
  {{-- Stats --}}
  <div class="grid grid-cols-2 xl:grid-cols-4 gap-4">
    @php
      $cards = [
        ['PCs in use', $stats['in_use'].' / '.$stats['total'], 'text-red-600 bg-red-50', $stats['available'].' available · '.$stats['maintenance'].' maintenance'],
        ['Registered customers', $stats['customers'], 'text-cn-main bg-blue-50', 'All accounts'],
        ['Sessions today', $stats['sessions_today'], 'text-emerald-600 bg-emerald-50', 'Time-ins since midnight'],
        ['Credit sales today', '₱'.number_format($stats['sales_today'], 2), 'text-amber-600 bg-amber-50', 'From playtime top-ups'],
      ];
    @endphp
    @foreach ($cards as [$label, $value, $tone, $hint])
      <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div class="text-xs font-bold uppercase tracking-wider text-slate-500">{{ $label }}</div>
        <div class="mt-2 text-3xl font-extrabold {{ explode(' ', $tone)[0] }}">{{ $value }}</div>
        <div class="mt-1 text-xs text-slate-400">{{ $hint }}</div>
      </div>
    @endforeach
  </div>

  {{-- PC grid --}}
  <section>
    <div class="flex items-center justify-between mb-3">
      <h2 class="text-base font-bold text-slate-900">Computer Stations</h2>
      <div class="flex items-center gap-4 text-xs text-slate-500">
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>Available</span>
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-red-500"></span>In use</span>
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span>Maintenance</span>
      </div>
    </div>

    @if ($computers->isEmpty())
      <div class="bg-white rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
        No computers yet. <a href="{{ route('computers.index') }}" class="text-cn-main font-semibold hover:underline">Add your first PC</a>.
      </div>
    @else
      <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4">
        @foreach ($computers as $pc)
          @php $session = $pc->activeSession; @endphp
          <div class="bg-white rounded-2xl shadow-sm border-2 overflow-hidden flex flex-col
                      {{ $session ? 'border-red-200' : ($pc->status === 'maintenance' ? 'border-amber-200' : 'border-emerald-200') }}">
            <div class="flex items-center justify-between px-4 py-3 {{ $session ? 'bg-red-50' : ($pc->status === 'maintenance' ? 'bg-amber-50' : 'bg-emerald-50') }}">
              <div>
                <div class="font-extrabold text-slate-900">{{ $pc->name }}</div>
                <div class="text-[11px] uppercase tracking-wider text-slate-500">{{ $pc->tier_label }}</div>
              </div>
              @if ($session)
                <span class="px-2.5 py-1 rounded-full bg-red-500 text-white text-xs font-bold">IN USE</span>
              @elseif ($pc->status === 'maintenance')
                <span class="px-2.5 py-1 rounded-full bg-amber-500 text-white text-xs font-bold">MAINTENANCE</span>
              @else
                <span class="px-2.5 py-1 rounded-full bg-emerald-500 text-white text-xs font-bold">AVAILABLE</span>
              @endif
            </div>

            <div class="p-4 flex-1 flex flex-col">
              @if ($session)
                @php $customer = $session->customer; @endphp
                <div x-data="sessionTimer({{ $session->started_at->valueOf() }}, {{ $customer->credit_minutes }}, {{ now()->valueOf() }})" class="flex-1 flex flex-col">
                  <div class="flex items-center gap-3">
                    <x-admin.avatar :customer="$customer" size="w-14 h-14" text="text-lg" />
                    <div class="min-w-0">
                      <a href="{{ route('customers.show', $customer) }}" class="font-bold text-slate-900 hover:text-cn-main truncate block">{{ $customer->full_name }}</a>
                      <div class="text-xs text-slate-500">{{ $customer->account_no }} · In at {{ $session->started_at->format('g:i A') }}</div>
                    </div>
                  </div>

                  <div class="mt-4 grid grid-cols-2 gap-3 text-center">
                    <div class="rounded-xl bg-slate-50 py-2">
                      <div class="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Elapsed</div>
                      <div class="font-mono text-lg font-bold text-slate-800" x-text="fmt(elapsed)">00:00:00</div>
                    </div>
                    <div class="rounded-xl py-2" :class="over ? 'bg-red-100' : (low ? 'bg-amber-50' : 'bg-slate-50')">
                      <div class="text-[10px] uppercase tracking-wider text-slate-400 font-bold" x-text="over ? 'Time is up' : 'Remaining'">Remaining</div>
                      <div class="font-mono text-lg font-bold" :class="over ? 'text-red-600' : (low ? 'text-amber-600' : 'text-slate-800')" x-text="over ? '00:00:00' : fmt(remaining)">--</div>
                    </div>
                  </div>

                  <div class="mt-3 h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full rounded-full transition-all" :class="over ? 'bg-red-500' : (low ? 'bg-amber-400' : 'bg-emerald-500')" :style="'width:' + percentLeft + '%'"></div>
                  </div>

                  <form method="POST" action="{{ route('sessions.end', $session) }}" class="mt-4"
                        onsubmit="return confirm('Time out {{ addslashes($customer->full_name) }} from {{ $pc->name }}?')">
                    @csrf @method('PATCH')
                    <button class="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-bold">Time Out</button>
                  </form>
                </div>
              @elseif ($pc->status === 'maintenance')
                <div class="flex-1 flex flex-col items-center justify-center py-6 text-amber-600">
                  <svg class="w-10 h-10 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M11.4 15.2l-5.1 5.1a2 2 0 01-2.8-2.8l5.1-5.1m2.8 2.8l1.5-1.5a5 5 0 006.4-6.4l-3.2 3.2-2.8-2.8 3.2-3.2a5 5 0 00-6.4 6.4l-1.5 1.5"/></svg>
                  <div class="text-sm font-semibold">Under maintenance</div>
                </div>
              @else
                <div class="flex-1 flex flex-col items-center justify-center py-4 text-slate-400">
                  <svg class="w-10 h-10 mb-2 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                  <div class="text-sm">Ready for a player</div>
                </div>
                <button type="button"
                        x-on:click="$dispatch('open-modal', { name: 'time-in', data: { computer_id: {{ $pc->id }}, name: @js($pc->name) } })"
                        class="mt-2 w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">Time In</button>
              @endif
            </div>
          </div>
        @endforeach
      </div>
    @endif
  </section>

  {{-- Recent activity --}}
  <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="flex items-center justify-between px-5 py-4 border-b border-slate-100">
      <h2 class="text-base font-bold text-slate-900">Recent Activity</h2>
      <a href="{{ route('sessions.index') }}" class="text-sm font-semibold text-cn-main hover:underline">View full time log →</a>
    </div>
    @include('sessions._table', ['sessions' => $recent])
  </section>

  {{-- Time-in modal --}}
  <x-admin.modal name="time-in" title="Time In" max-width="max-w-md">
    <form method="POST" action="{{ route('sessions.store') }}"
          x-data="{ q: '', selected: null, customers: @js($eligibleCustomers) }"
          x-effect="if (!show) { selected = null; q = '' }">
      @csrf
      <input type="hidden" name="computer_id" :value="data.computer_id">
      <p class="text-sm text-slate-500 mb-3">Choose a customer to start on <span class="font-bold text-slate-800" x-text="data.name"></span>.</p>

      <input type="search" x-model="q" placeholder="Search name or account no…"
             class="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">

      <div class="mt-3 max-h-72 overflow-y-auto space-y-2 pr-1">
        <template x-for="c in customers.filter(c => (c.name + ' ' + c.account_no).toLowerCase().includes(q.toLowerCase()))" :key="c.id">
          <label class="flex items-center gap-3 p-2.5 rounded-xl border-2 cursor-pointer transition"
                 :class="selected === c.id ? 'border-cn-main bg-blue-50' : 'border-slate-100 hover:border-slate-300'">
            <input type="radio" name="customer_id" :value="c.id" x-model.number="selected" class="sr-only">
            <template x-if="c.photo"><img :src="c.photo" :alt="c.name" class="w-11 h-11 rounded-full object-cover ring-2 ring-white shadow"></template>
            <template x-if="!c.photo"><div class="w-11 h-11 rounded-full bg-gradient-to-br from-cn-main to-cn-dark text-white font-bold flex items-center justify-center text-sm ring-2 ring-white shadow" x-text="c.initials"></div></template>
            <div class="min-w-0 flex-1">
              <div class="font-semibold text-slate-900 truncate" x-text="c.name"></div>
              <div class="text-xs text-slate-500" x-text="c.account_no"></div>
            </div>
            <div class="text-right">
              <div class="text-xs text-slate-400">Credits</div>
              <div class="text-sm font-bold text-emerald-600" x-text="c.credit"></div>
            </div>
          </label>
        </template>
        <p class="text-sm text-slate-400 text-center py-6" x-show="customers.length === 0">
          No customers with available credits. <a href="{{ route('customers.index') }}" class="text-cn-main font-semibold hover:underline">Add credits</a>
        </p>
      </div>

      <div class="mt-5 flex justify-end gap-2">
        <button type="button" x-on:click="show = false" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Cancel</button>
        <button type="submit" :disabled="!selected" class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold">Start Session</button>
      </div>
    </form>
  </x-admin.modal>
@endsection
