<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\DB;

#[Fillable(['customer_id', 'computer_id', 'user_id', 'started_at', 'ended_at', 'minutes_charged'])]
class PlaySession extends Model
{
    protected $table = 'play_sessions';

    protected function casts(): array
    {
        return [
            'started_at' => 'datetime',
            'ended_at' => 'datetime',
            'minutes_charged' => 'integer',
        ];
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function computer(): BelongsTo
    {
        return $this->belongsTo(Computer::class);
    }

    public function admin(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->whereNull('ended_at');
    }

    public function isActive(): bool
    {
        return $this->ended_at === null;
    }

    /**
     * Minutes elapsed so far (or total if finished), rounded up to the next minute.
     */
    public function elapsedMinutes(): int
    {
        $end = $this->ended_at ?? now();

        return max(1, (int) ceil(abs($end->diffInSeconds($this->started_at, true)) / 60));
    }

    /**
     * Time the customer out and deduct the used minutes from their credits.
     * Returns the number of minutes charged.
     */
    public function timeOut(): int
    {
        return DB::transaction(function () {
            $customer = Customer::lockForUpdate()->findOrFail($this->customer_id);

            $charged = min($this->elapsedMinutes(), $customer->credit_minutes);

            $customer->decrement('credit_minutes', $charged);

            $this->update([
                'ended_at' => now(),
                'minutes_charged' => $charged,
            ]);

            return $charged;
        });
    }
}
