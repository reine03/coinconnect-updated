<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class CustomerController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim((string) $request->query('q'));

        $customers = Customer::with('activeSession.computer')
            ->when($search !== '', fn ($query) => $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                    ->orWhere('account_no', 'like', "%{$search}%")
                    ->orWhere('contact_number', 'like', "%{$search}%");
            }))
            ->orderBy('full_name')
            ->paginate(12)
            ->withQueryString();

        return view('customers.index', compact('customers', 'search'));
    }

    public function show(Customer $customer): View
    {
        $customer->load('activeSession.computer');

        $sessions = $customer->sessions()->with('computer')->latest('started_at')->limit(15)->get();
        $transactions = $customer->creditTransactions()->with('admin')->latest()->limit(15)->get();

        return view('customers.show', compact('customer', 'sessions', 'transactions'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'full_name' => ['required', 'string', 'min:2', 'max:100'],
            'contact_number' => ['nullable', 'string', 'regex:/^[0-9+\-\s()]{7,20}$/'],
            'email' => ['nullable', 'email', 'max:255'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'initial_hours' => ['nullable', 'numeric', 'min:0', 'max:100'],
        ], [
            'contact_number.regex' => 'Enter a valid contact number.',
            'photo.max' => 'The photo must not be larger than 2 MB.',
        ]);

        $customer = Customer::create([
            'full_name' => $data['full_name'],
            'contact_number' => $data['contact_number'] ?? null,
            'email' => $data['email'] ?? null,
            'photo_path' => $request->hasFile('photo') ? $request->file('photo')->store('customers', 'public') : null,
            'credit_minutes' => (int) round(((float) ($data['initial_hours'] ?? 0)) * 60),
            'is_active' => true,
        ]);

        $customer->update(['account_no' => 'CN-'.str_pad((string) $customer->id, 5, '0', STR_PAD_LEFT)]);

        if ($customer->credit_minutes > 0) {
            $customer->creditTransactions()->create([
                'user_id' => $request->user()->id,
                'type' => 'purchase',
                'minutes' => $customer->credit_minutes,
                'amount' => 0,
                'note' => 'Starting credits',
            ]);
        }

        return redirect()->route('customers.show', $customer)
            ->with('success', "{$customer->full_name} was registered as {$customer->account_no}.");
    }

    public function update(Request $request, Customer $customer): RedirectResponse
    {
        $data = $request->validate([
            'full_name' => ['required', 'string', 'min:2', 'max:100'],
            'contact_number' => ['nullable', 'string', 'regex:/^[0-9+\-\s()]{7,20}$/'],
            'email' => ['nullable', 'email', 'max:255'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'is_active' => ['required', 'boolean'],
        ], [
            'contact_number.regex' => 'Enter a valid contact number.',
            'photo.max' => 'The photo must not be larger than 2 MB.',
        ]);

        if (! $data['is_active'] && $customer->activeSession()->exists()) {
            return back()->withErrors(['is_active' => 'This customer is currently playing. Time them out before deactivating.']);
        }

        if ($request->hasFile('photo')) {
            if ($customer->photo_path) {
                Storage::disk('public')->delete($customer->photo_path);
            }
            $data['photo_path'] = $request->file('photo')->store('customers', 'public');
        }

        unset($data['photo']);
        $customer->update($data);

        return back()->with('success', 'Customer details were updated.');
    }

    public function destroy(Customer $customer): RedirectResponse
    {
        if ($customer->activeSession()->exists()) {
            return back()->withErrors(['delete' => 'This customer is currently playing. Time them out first.']);
        }

        if ($customer->photo_path) {
            Storage::disk('public')->delete($customer->photo_path);
        }

        $name = $customer->full_name;
        $customer->delete();

        return redirect()->route('customers.index')->with('success', "{$name} was deleted.");
    }
}
