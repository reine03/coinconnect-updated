<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Registration - Coinnect</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
  <style>
    [x-cloak] { display: none !important; }
    .cn-blue-dark { background-color: #0d3b66; }
    .cn-blue-main { background-color: #1e3a8a; }
    .cn-text-blue { color: #1e3a8a; }
    .gold-ring {
      background: conic-gradient(#ffd700 0deg 120deg, #ffcc00 120deg 240deg, #b8860b 240deg 360deg);
    }
    body {
      background: linear-gradient(135deg, #cfd3db 0%, #a9afba 50%, #7c818a 100%);
      min-height: 100vh;
      font-family: sans-serif;
      position: relative;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      background-image: linear-gradient(#00000012 1px, transparent 1px), linear-gradient(90deg, #00000012 1px, transparent 1px);
      background-size: 40px 40px;
      pointer-events: none;
    }
    body::after {
      content: "";
      position: fixed;
      inset: 0;
      background: radial-gradient(circle at center, transparent 65%, rgba(0,0,0,0.25) 100%);
      pointer-events: none;
    }
  </style>
</head>
<body class="flex items-center justify-center p-4 font-sans">

  <div class="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 relative z-10 my-6">
    <div class="cn-blue-dark p-6 text-center flex flex-col items-center justify-center">
      <div class="relative w-20 h-20 rounded-full p-1 gold-ring shadow-lg mb-3">
        <div class="w-full h-full bg-[#ffd700] rounded-full flex items-center justify-center overflow-hidden">
          <svg viewBox="0 0 100 100" class="w-14 h-14 fill-white">
            <circle cx="50" cy="50" r="20" />
            <path d="M40 50 L60 50 M50 40 L50 60" stroke="white" stroke-width="4"/>
          </svg>
        </div>
      </div>
      <h1 class="text-2xl font-extrabold text-white tracking-wide">COINNECT</h1>
      <p class="text-blue-200 text-sm mt-1 font-medium">Create your admin account 🎮</p>
    </div>

    <form action="{{ route('register') }}" method="POST" class="p-8 space-y-4" novalidate
          x-data="registerForm({{ Js::from(['username' => old('username', ''), 'password' => '']) }})"
          x-on:submit="if (!canSubmit) { $event.preventDefault(); touched = true; } else { busy = true }">
      @csrf

      <div>
        <label for="name" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Full Name</label>
        <input type="text" id="name" name="name" value="{{ old('name') }}" required autocomplete="name" maxlength="60"
               class="w-full px-4 py-3 rounded-lg border @error('name') border-red-400 @else border-gray-300 @enderror focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
               placeholder="e.g. Juan Dela Cruz">
        @error('name') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
      </div>

      {{-- Username --}}
      <div>
        <label for="username" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Username</label>
        <input type="text" id="username" name="username" x-model="username" required autocomplete="username" maxlength="20" autocapitalize="none" spellcheck="false"
               class="w-full px-4 py-3 rounded-lg border @error('username') border-red-400 @else border-gray-300 @enderror focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
               placeholder="e.g. juan_admin">
        @error('username') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
        <ul class="mt-2 space-y-1 text-xs" x-cloak x-show="username.length > 0 || touched">
          <template x-for="rule in usernameRules" :key="rule.label">
            <li class="flex items-center gap-2" :class="rule.ok ? 'text-green-600' : 'text-gray-500'">
              <span class="inline-flex w-4 h-4 items-center justify-center rounded-full text-[10px] font-bold text-white" :class="rule.ok ? 'bg-green-500' : 'bg-gray-300'" x-text="rule.ok ? '✓' : '•'"></span>
              <span x-text="rule.label"></span>
            </li>
          </template>
        </ul>
        <p class="text-xs text-gray-400 mt-1" x-show="username.length === 0 && !touched">4–20 characters. Letters, numbers and underscores only. Not case-sensitive.</p>
      </div>

      <div>
        <label for="email" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Email Address</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}" required autocomplete="email"
               class="w-full px-4 py-3 rounded-lg border @error('email') border-red-400 @else border-gray-300 @enderror focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
               placeholder="name@example.com">
        @error('email') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
      </div>

      {{-- Password --}}
      <div>
        <label for="password" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Password</label>
        <div class="relative">
          <input :type="show ? 'text' : 'password'" id="password" name="password" x-model="password" required autocomplete="new-password" maxlength="64"
                 class="w-full px-4 py-3 pr-14 rounded-lg border @error('password') border-red-400 @else border-gray-300 @enderror focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
                 placeholder="••••••••">
          <button type="button" x-on:click="show = !show" class="absolute inset-y-0 right-0 px-4 text-xs font-bold text-gray-500 hover:text-[#1e3a8a]">
            <span x-text="show ? 'HIDE' : 'SHOW'">SHOW</span>
          </button>
        </div>
        @error('password') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror

        <div class="mt-2" x-cloak x-show="password.length > 0">
          <div class="flex gap-1">
            <template x-for="i in 4" :key="i">
              <div class="h-1.5 flex-1 rounded-full transition-colors" :class="i <= strength.score ? strength.color : 'bg-gray-200'"></div>
            </template>
          </div>
          <p class="text-xs mt-1 font-semibold" :class="strength.text" x-text="strength.label"></p>
        </div>

        <ul class="mt-2 space-y-1 text-xs" x-cloak x-show="password.length > 0 || touched">
          <template x-for="rule in passwordRules" :key="rule.label">
            <li class="flex items-center gap-2" :class="rule.ok ? 'text-green-600' : 'text-gray-500'">
              <span class="inline-flex w-4 h-4 items-center justify-center rounded-full text-[10px] font-bold text-white" :class="rule.ok ? 'bg-green-500' : 'bg-gray-300'" x-text="rule.ok ? '✓' : '•'"></span>
              <span x-text="rule.label"></span>
            </li>
          </template>
        </ul>
        <p class="text-xs text-gray-400 mt-1" x-show="password.length === 0 && !touched">At least 8 characters with upper &amp; lower case, a number and a symbol.</p>
      </div>

      <div>
        <label for="password_confirmation" class="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Confirm Password</label>
        <input :type="show ? 'text' : 'password'" id="password_confirmation" name="password_confirmation" x-model="confirm" required autocomplete="new-password" maxlength="64"
               class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent transition"
               placeholder="••••••••">
        <p class="text-xs mt-1" x-cloak x-show="confirm.length > 0" :class="matches ? 'text-green-600' : 'text-red-500'" x-text="matches ? '✓ Passwords match' : 'Passwords do not match'"></p>
      </div>

      <button type="submit" x-bind:disabled="busy"
              class="w-full mt-2 cn-blue-main hover:bg-[#0d3b66] disabled:opacity-70 text-white font-bold py-3.5 px-4 rounded-full shadow-md hover:shadow-lg transition duration-200"
              :class="!canSubmit && 'opacity-60'">
        <span x-text="busy ? 'Creating account…' : 'Create Admin Account'">Create Admin Account</span>
      </button>
      <p class="text-xs text-center text-red-500" x-cloak x-show="touched && !canSubmit">Please complete all the requirements above.</p>
    </form>

    <div class="px-8 pb-8 text-center bg-gray-50 border-t border-gray-100 pt-4">
      <p class="text-sm text-gray-600">Already have an account?</p>
      <a href="{{ route('login') }}" class="cn-text-blue font-bold text-sm hover:underline mt-1 inline-block">Sign In to Coinnect</a>
    </div>
  </div>

  <script>
    document.addEventListener('alpine:init', () => {
      Alpine.data('registerForm', (initial) => ({
        username: initial.username,
        password: '',
        confirm: '',
        show: false,
        touched: false,
        busy: false,

        get usernameRules() {
          const u = this.username;
          return [
            { label: '4 to 20 characters', ok: u.length >= 4 && u.length <= 20 },
            { label: 'Starts with a letter', ok: /^[A-Za-z]/.test(u) },
            { label: 'Only letters, numbers and underscores', ok: u.length > 0 && /^[A-Za-z0-9_]+$/.test(u) },
          ];
        },
        get passwordRules() {
          const p = this.password;
          const u = this.username.toLowerCase();
          return [
            { label: 'At least 8 characters', ok: p.length >= 8 },
            { label: 'An uppercase letter (A-Z)', ok: /[A-Z]/.test(p) },
            { label: 'A lowercase letter (a-z)', ok: /[a-z]/.test(p) },
            { label: 'A number (0-9)', ok: /[0-9]/.test(p) },
            { label: 'A symbol (e.g. ! @ # $ %)', ok: /[^A-Za-z0-9]/.test(p) },
            { label: 'Does not contain your username', ok: p.length > 0 && !(u.length > 0 && p.toLowerCase().includes(u)) },
          ];
        },
        get strength() {
          const passed = this.passwordRules.filter(r => r.ok).length;
          const extra = this.password.length >= 12 ? 1 : 0;
          const score = Math.min(4, Math.max(1, Math.round(((passed + extra) / 7) * 4)));
          const levels = [
            null,
            { label: 'Weak', color: 'bg-red-500', text: 'text-red-600' },
            { label: 'Fair', color: 'bg-orange-400', text: 'text-orange-500' },
            { label: 'Good', color: 'bg-yellow-400', text: 'text-yellow-600' },
            { label: 'Strong', color: 'bg-green-500', text: 'text-green-600' },
          ];
          return { score, ...levels[score] };
        },
        get matches() {
          return this.password.length > 0 && this.password === this.confirm;
        },
        get canSubmit() {
          return this.usernameRules.every(r => r.ok) && this.passwordRules.every(r => r.ok) && this.matches;
        },
      }));
    });
  </script>
</body>
</html>
