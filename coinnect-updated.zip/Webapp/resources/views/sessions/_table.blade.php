<div class="overflow-x-auto">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
      <tr>
        <th class="px-5 py-3 text-left font-bold">Customer</th>
        <th class="px-5 py-3 text-left font-bold">PC</th>
        <th class="px-5 py-3 text-left font-bold">Time In</th>
        <th class="px-5 py-3 text-left font-bold">Time Out</th>
        <th class="px-5 py-3 text-left font-bold">Duration</th>
        <th class="px-5 py-3 text-left font-bold">Credits used</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-100">
      @forelse ($sessions as $s)
        <tr class="hover:bg-slate-50">
          <td class="px-5 py-3">
            <a href="{{ route('customers.show', $s->customer) }}" class="flex items-center gap-3 group">
              <x-admin.avatar :customer="$s->customer" size="w-9 h-9" text="text-xs" />
              <div>
                <div class="font-semibold text-slate-900 group-hover:text-cn-main">{{ $s->customer->full_name }}</div>
                <div class="text-xs text-slate-400">{{ $s->customer->account_no }}</div>
              </div>
            </a>
          </td>
          <td class="px-5 py-3 font-semibold">{{ $s->computer->name }}</td>
          <td class="px-5 py-3 text-slate-600 whitespace-nowrap">{{ $s->started_at->format('M j, g:i A') }}</td>
          <td class="px-5 py-3 whitespace-nowrap">
            @if ($s->ended_at)
              <span class="text-slate-600">{{ $s->ended_at->format('M j, g:i A') }}</span>
            @else
              <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold"><span class="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>Playing</span>
            @endif
          </td>
          <td class="px-5 py-3 text-slate-600 whitespace-nowrap">{{ \App\Models\Customer::formatMinutes($s->elapsedMinutes()) }}</td>
          <td class="px-5 py-3 whitespace-nowrap">{!! $s->ended_at ? '<span class="font-semibold">'.\App\Models\Customer::formatMinutes($s->minutes_charged).'</span>' : '<span class="text-slate-400">—</span>' !!}</td>
        </tr>
      @empty
        <tr><td colspan="6" class="px-5 py-10 text-center text-slate-400">No sessions yet.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
