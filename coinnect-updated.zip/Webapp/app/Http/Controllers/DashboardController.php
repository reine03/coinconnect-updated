<?php

namespace App\Http\Controllers;

use App\Models\Computer;
use App\Models\CreditTransaction;
use App\Models\Customer;
use App\Models\PlaySession;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $computers = Computer::with('activeSession.customer')->orderBy('name')->get();

        $inUse = $computers->filter(fn (Computer $pc) => $pc->activeSession !== null)->count();
        $maintenance = $computers->where('status', 'maintenance')->count();

        $stats = [
            'total' => $computers->count(),
            'in_use' => $inUse,
            'maintenance' => $maintenance,
            'available' => $computers->count() - $inUse - $maintenance,
            'customers' => Customer::count(),
            'sessions_today' => PlaySession::whereDate('started_at', today())->count(),
            'sales_today' => (float) CreditTransaction::where('type', 'purchase')->whereDate('created_at', today())->sum('amount'),
        ];

        // Customers who can be timed in right now.
        $eligibleCustomers = Customer::where('is_active', true)
            ->where('credit_minutes', '>', 0)
            ->whereDoesntHave('activeSession')
            ->orderBy('full_name')
            ->get()
            ->map(fn (Customer $c) => [
                'id' => $c->id,
                'name' => $c->full_name,
                'account_no' => $c->account_no,
                'credit' => $c->credit_label,
                'photo' => $c->photo_url,
                'initials' => $c->initials,
            ]);

        $recent = PlaySession::with(['customer', 'computer'])->latest('started_at')->limit(8)->get();

        return view('dashboard', compact('computers', 'stats', 'eligibleCustomers', 'recent'));
    }
}
