<?php

namespace Database\Seeders;

use App\Models\Computer;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database with a demo admin, PCs and customers.
     * Demo login: admin / Admin@12345  (change or remove before going live!)
     */
    public function run(): void
    {
        User::updateOrCreate(['username' => 'admin'], [
            'name' => 'Cafe Admin',
            'email' => 'admin@coinnect.test',
            'password' => 'Admin@12345', // hashed by the model cast
        ]);

        foreach (range(1, 10) as $number) {
            Computer::firstOrCreate(['name' => 'PC-'.str_pad((string) $number, 2, '0', STR_PAD_LEFT)], [
                'tier' => $number <= 6 ? 'standard' : ($number <= 9 ? 'premium' : 'vip'),
                'specs' => $number <= 6
                    ? 'Ryzen 5 / GTX 1660 / 16GB RAM / 144Hz'
                    : ($number <= 9 ? 'Ryzen 7 / RTX 4060 / 16GB RAM / 165Hz' : 'Ryzen 9 / RTX 4070 / 32GB RAM / 240Hz'),
                'status' => 'available',
            ]);
        }

        $demo = [
            ['Juan Dela Cruz', '0917 123 4567', 180],
            ['Maria Santos', '0918 222 3333', 120],
            ['Carlo Reyes', '0927 555 8899', 60],
            ['Angela Bautista', '0995 444 1212', 300],
        ];

        foreach ($demo as [$name, $contact, $minutes]) {
            $customer = Customer::firstOrCreate(['full_name' => $name], [
                'contact_number' => $contact,
                'credit_minutes' => $minutes,
                'is_active' => true,
            ]);
            $customer->update(['account_no' => 'CN-'.str_pad((string) $customer->id, 5, '0', STR_PAD_LEFT)]);
        }
    }
}
