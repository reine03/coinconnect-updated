@extends('layouts.admin')

@section('title', 'Customers')
@section('heading', 'Customers')
@section('subheading', 'Register accounts, top up playtime and manage photos')

@section('actions')
  <button type="button" x-data x-on:click="$dispatch('open-modal', { name: 'register-customer' })"
          class="inline-flex items-center px-4 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-semibold shadow-sm">+ Register customer</button>
@endsection

@section('content')
  <form method="GET" class="flex gap-2">
    <input type="search" name="q" value="{{ $search }}" placeholder="Search by name, account no. or contact…"
           class="flex-1 max-w-md px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
    <button class="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold">Search</button>
    @if ($search)<a href="{{ route('customers.index') }}" class="px-3 py-2.5 text-sm font-semibold text-slate-500 hover:text-slate-800">Clear</a>@endif
  </form>

  @if ($customers->isEmpty())
    <div class="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center text-slate-500">
      {{ $search ? 'No customers match your search.' : 'No customers registered yet.' }}
    </div>
  @else
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4">
      @foreach ($customers as $customer)
        @php $session = $customer->activeSession; @endphp
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex flex-col items-center text-center {{ $customer->is_active ? '' : 'opacity-60' }}">
          <a href="{{ route('customers.show', $customer) }}">
            <x-admin.avatar :customer="$customer" size="w-24 h-24" text="text-3xl" />
          </a>
          <a href="{{ route('customers.show', $customer) }}" class="mt-3 font-bold text-slate-900 hover:text-cn-main leading-tight">{{ $customer->full_name }}</a>
          <div class="text-xs text-slate-400 mt-0.5">{{ $customer->account_no }}</div>

          <div class="mt-3 flex items-center gap-2 flex-wrap justify-center">
            @if (! $customer->is_active)
              <span class="px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-600 text-xs font-bold">Inactive</span>
            @elseif ($session)
              <span class="px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold">Playing · {{ $session->computer->name }}</span>
            @else
              <span class="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs font-bold">Offline</span>
            @endif
          </div>

          <div class="mt-4 w-full rounded-xl bg-slate-50 py-2.5">
            <div class="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Playtime credits</div>
            <div class="text-xl font-extrabold {{ $customer->credit_minutes > 0 ? 'text-emerald-600' : 'text-red-500' }}">{{ $customer->credit_label }}</div>
          </div>

          <div class="mt-4 w-full grid grid-cols-2 gap-2">
            <a href="{{ route('customers.show', $customer) }}" class="py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Profile</a>
            <button type="button" x-data
                    x-on:click="$dispatch('open-modal', { name: 'credits', data: { id: {{ $customer->id }}, name: @js($customer->full_name), balance: @js($customer->credit_label) } })"
                    class="py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">+ Credits</button>
          </div>
        </div>
      @endforeach
    </div>

    @if ($customers->hasPages())
      <div>{{ $customers->links() }}</div>
    @endif
  @endif

  @include('customers._credit-modal')

  {{-- Register customer modal --}}
  <x-admin.modal name="register-customer" title="Register customer" max-width="max-w-xl">
    <form method="POST" action="{{ route('customers.store') }}" enctype="multipart/form-data" class="space-y-4">
      @csrf
      <x-admin.photo-picker />

      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Full name</label>
        <input type="text" name="full_name" required maxlength="100" placeholder="e.g. Juan Dela Cruz"
               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
      </div>
      <div class="grid sm:grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Contact no. <span class="font-normal normal-case text-slate-400">(optional)</span></label>
          <input type="text" name="contact_number" maxlength="20" placeholder="0917 123 4567"
                 class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
        </div>
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Email <span class="font-normal normal-case text-slate-400">(optional)</span></label>
          <input type="email" name="email" maxlength="255" placeholder="name@example.com"
                 class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
        </div>
      </div>
      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Starting playtime (hours) <span class="font-normal normal-case text-slate-400">(optional)</span></label>
        <input type="number" name="initial_hours" step="0.25" min="0" max="100" placeholder="0"
               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
      </div>

      <div class="flex justify-end gap-2 pt-2">
        <button type="button" x-on:click="show = false" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Cancel</button>
        <button type="submit" class="px-5 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-bold">Register</button>
      </div>
    </form>
  </x-admin.modal>
@endsection
