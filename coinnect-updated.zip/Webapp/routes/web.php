<?php

use App\Http\Controllers\ComputerController;
use App\Http\Controllers\CreditController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PlaySessionController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::resource('computers', ComputerController::class)->only(['index', 'store', 'update', 'destroy']);

    Route::resource('customers', CustomerController::class)->only(['index', 'show', 'store', 'update', 'destroy']);
    Route::post('/customers/{customer}/credits', [CreditController::class, 'store'])->name('customers.credits.store');

    Route::get('/sessions', [PlaySessionController::class, 'index'])->name('sessions.index');
    Route::post('/sessions', [PlaySessionController::class, 'store'])->name('sessions.store');
    Route::patch('/sessions/{session}/end', [PlaySessionController::class, 'end'])->name('sessions.end');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
