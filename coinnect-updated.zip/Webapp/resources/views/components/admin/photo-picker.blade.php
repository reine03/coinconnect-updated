@props(['current' => null, 'initials' => null])
<div x-data="photoPicker(@js($current))" class="flex items-center gap-4">
  <div class="relative w-24 h-24 shrink-0">
    <template x-if="preview">
      <img :src="preview" alt="Photo preview" class="w-24 h-24 rounded-full object-cover ring-4 ring-slate-100 shadow">
    </template>
    <template x-if="!preview">
      <div class="w-24 h-24 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center ring-4 ring-slate-100">
        <svg class="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
      </div>
    </template>
  </div>

  <div class="space-y-2 min-w-0">
    <div class="flex flex-wrap gap-2">
      <label class="cursor-pointer inline-flex items-center px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold text-slate-700">
        Upload photo
        <input type="file" name="photo" accept="image/png,image/jpeg,image/webp" class="sr-only" x-ref="file" x-on:change="pick($event)">
      </label>
      <button type="button" x-on:click="openCamera()" class="inline-flex items-center px-3 py-1.5 rounded-lg bg-cn-main hover:bg-cn-dark text-sm font-semibold text-white">Use camera</button>
    </div>
    <p class="text-xs text-slate-400">JPG, PNG or WebP. Max 2 MB.</p>
    <p class="text-xs text-red-500" x-show="error" x-text="error"></p>
  </div>

  {{-- Camera overlay --}}
  <div x-cloak x-show="camera" class="fixed inset-0 z-[60] bg-black/80 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl p-4 w-full max-w-md space-y-3">
      <video x-ref="video" autoplay playsinline muted class="w-full aspect-square object-cover rounded-xl bg-black"></video>
      <div class="flex gap-2 justify-end">
        <button type="button" x-on:click="closeCamera()" class="px-4 py-2 rounded-lg bg-slate-100 text-sm font-semibold hover:bg-slate-200">Cancel</button>
        <button type="button" x-on:click="snap()" class="px-4 py-2 rounded-lg bg-cn-main text-white text-sm font-semibold hover:bg-cn-dark">Take photo</button>
      </div>
    </div>
  </div>
</div>
