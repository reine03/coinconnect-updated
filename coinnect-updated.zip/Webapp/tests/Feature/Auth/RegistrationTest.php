<?php

use App\Models\User;

function validRegistration(array $overrides = []): array
{
    return array_merge([
        'name' => 'Test Admin',
        'username' => 'test_admin',
        'email' => 'test@example.com',
        'password' => 'Str0ng!Passw0rd',
        'password_confirmation' => 'Str0ng!Passw0rd',
    ], $overrides);
}

test('registration screen can be rendered', function () {
    $this->get('/register')->assertStatus(200);
});

test('new admins can register and are sent to the login page without being logged in', function () {
    $response = $this->post('/register', validRegistration());

    $this->assertGuest();
    $response->assertRedirect(route('login'));
    $response->assertSessionHas('status');
    expect(User::where('username', 'test_admin')->exists())->toBeTrue();
});

test('usernames are validated', function (string $username) {
    $this->post('/register', validRegistration(['username' => $username]))
        ->assertSessionHasErrors('username');

    $this->assertGuest();
})->with([
    'too short' => 'abc',
    'too long' => 'this_username_is_way_too_long',
    'starts with a number' => '1admin',
    'has spaces' => 'bad name',
    'has symbols' => 'bad-name!',
]);

test('usernames must be unique regardless of case', function () {
    User::factory()->create(['username' => 'taken_name']);

    $this->post('/register', validRegistration(['username' => 'Taken_Name']))
        ->assertSessionHasErrors('username');
});

test('passwords must meet the requirements', function (string $password) {
    $this->post('/register', validRegistration([
        'password' => $password,
        'password_confirmation' => $password,
    ]))->assertSessionHasErrors('password');
})->with([
    'too short' => 'Ab1!',
    'no uppercase' => 'str0ng!passw0rd',
    'no lowercase' => 'STR0NG!PASSW0RD',
    'no number' => 'Strong!Password',
    'no symbol' => 'Str0ngPassw0rd',
    'contains username' => 'Xtest_admin1!',
]);

test('password confirmation must match', function () {
    $this->post('/register', validRegistration(['password_confirmation' => 'Different1!']))
        ->assertSessionHasErrors('password');
});
