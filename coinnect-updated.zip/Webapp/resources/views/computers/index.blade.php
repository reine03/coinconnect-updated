@extends('layouts.admin')

@section('title', 'Computers')
@section('heading', 'Computers')
@section('subheading', 'Add, edit and manage the PCs in your cafe')

@section('actions')
  <button type="button" x-data x-on:click="$dispatch('open-modal', { name: 'pc-form', data: { id: null, name: '', tier: 'standard', specs: '', status: 'available' } })"
          class="inline-flex items-center px-4 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-semibold shadow-sm">+ Add computer</button>
@endsection

@section('content')
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
          <tr>
            <th class="px-5 py-3 text-left font-bold">PC</th>
            <th class="px-5 py-3 text-left font-bold">Tier</th>
            <th class="px-5 py-3 text-left font-bold">Specs</th>
            <th class="px-5 py-3 text-left font-bold">Status</th>
            <th class="px-5 py-3 text-left font-bold">Current user</th>
            <th class="px-5 py-3 text-right font-bold">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          @forelse ($computers as $pc)
            @php $session = $pc->activeSession; @endphp
            <tr class="hover:bg-slate-50">
              <td class="px-5 py-3 font-bold text-slate-900">{{ $pc->name }}</td>
              <td class="px-5 py-3">
                <span class="px-2 py-0.5 rounded-full text-xs font-bold {{ $pc->tier === 'vip' ? 'bg-amber-100 text-amber-700' : ($pc->tier === 'premium' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600') }}">{{ $pc->tier_label }}</span>
              </td>
              <td class="px-5 py-3 text-slate-500 max-w-xs truncate">{{ $pc->specs ?: '—' }}</td>
              <td class="px-5 py-3">
                @if ($session)
                  <span class="px-2.5 py-1 rounded-full bg-red-100 text-red-700 text-xs font-bold">In use</span>
                @elseif ($pc->status === 'maintenance')
                  <span class="px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-bold">Maintenance</span>
                @else
                  <span class="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">Available</span>
                @endif
              </td>
              <td class="px-5 py-3">
                @if ($session)
                  <a href="{{ route('customers.show', $session->customer) }}" class="flex items-center gap-2 hover:text-cn-main">
                    <x-admin.avatar :customer="$session->customer" size="w-8 h-8" text="text-xs" />
                    <span class="font-semibold">{{ $session->customer->full_name }}</span>
                  </a>
                @else
                  <span class="text-slate-400">—</span>
                @endif
              </td>
              <td class="px-5 py-3 text-right whitespace-nowrap" x-data>
                <button type="button"
                        x-on:click="$dispatch('open-modal', { name: 'pc-form', data: { id: {{ $pc->id }}, name: @js($pc->name), tier: @js($pc->tier), specs: @js($pc->specs ?? ''), status: @js($pc->status) } })"
                        class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200">Edit</button>
                <form method="POST" action="{{ route('computers.destroy', $pc) }}" class="inline"
                      onsubmit="return confirm('Delete {{ addslashes($pc->name) }}? This cannot be undone.')">
                  @csrf @method('DELETE')
                  <button class="px-3 py-1.5 rounded-lg text-xs font-semibold text-red-600 hover:bg-red-50">Delete</button>
                </form>
              </td>
            </tr>
          @empty
            <tr><td colspan="6" class="px-5 py-12 text-center text-slate-400">No computers yet. Click “Add computer” to get started.</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>

  {{-- Add / edit modal --}}
  <x-admin.modal name="pc-form" title="Computer details">
    <form method="POST" class="space-y-4"
          x-bind:action="data.id ? '{{ route('computers.update', ':id') }}'.replace(':id', data.id) : '{{ route('computers.store') }}'">
      @csrf
      <input type="hidden" name="_form" value="pc">
      <template x-if="data.id"><input type="hidden" name="_method" value="PATCH"></template>

      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">PC name</label>
        <input type="text" name="name" required maxlength="30" x-bind:value="data.name || @js(old('name'))" placeholder="e.g. PC-11"
               class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent">
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Tier</label>
          <select name="tier" x-bind:value="data.tier" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main">
            @foreach (\App\Models\Computer::TIERS as $value => $label)
              <option value="{{ $value }}" :selected="data.tier === '{{ $value }}'">{{ $label }}</option>
            @endforeach
          </select>
        </div>
        <div>
          <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Status</label>
          <select name="status" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main">
            @foreach (\App\Models\Computer::STATUSES as $value => $label)
              <option value="{{ $value }}" :selected="data.status === '{{ $value }}'">{{ $label }}</option>
            @endforeach
          </select>
        </div>
      </div>

      <div>
        <label class="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Specs <span class="font-normal normal-case text-slate-400">(optional)</span></label>
        <textarea name="specs" rows="2" maxlength="500" x-bind:value="data.specs" placeholder="e.g. Ryzen 5 / RTX 3060 / 16GB RAM / 144Hz"
                  class="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cn-main focus:border-transparent"></textarea>
      </div>

      <div class="flex justify-end gap-2 pt-2">
        <button type="button" x-on:click="show = false" class="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-semibold">Cancel</button>
        <button type="submit" class="px-5 py-2 rounded-lg bg-cn-main hover:bg-cn-dark text-white text-sm font-bold">Save</button>
      </div>
    </form>
  </x-admin.modal>
@endsection
