<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

#[Fillable(['name', 'tier', 'specs', 'status'])]
class Computer extends Model
{
    public const TIERS = ['standard' => 'Standard', 'premium' => 'Premium', 'vip' => 'VIP'];

    public const STATUSES = ['available' => 'Available', 'maintenance' => 'Maintenance'];

    public function sessions(): HasMany
    {
        return $this->hasMany(PlaySession::class);
    }

    public function activeSession(): HasOne
    {
        return $this->hasOne(PlaySession::class)->whereNull('ended_at');
    }

    public function getTierLabelAttribute(): string
    {
        return self::TIERS[$this->tier] ?? ucfirst($this->tier);
    }
}
